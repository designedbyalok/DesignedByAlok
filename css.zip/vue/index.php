<?php


	echo '<title>Vue.js Installed</title><div style="background: #e9ffed; border: 1px solid #b0dab7; padding: 15px;" align="center" >
	<font size="5" color="#182e7a">Vue.js is installed successfully.</font><br /><br />
	<font size="4">Vue.js is a JavaScript, so doesn\'t have an index page.<br /><br />
	Vue.js is a library for building interactive web interfaces. It provides data-reactive components with a simple and flexible API. </font></div>';

?>